//Проверка на робота не проходит
describe('Тестирование регистрации hh.ru', function() {
    beforeEach(() => {
        cy.visit('https://voronezh.hh.ru/account/login')
      })

    it('Позитивный кейс: верный email', function() {
      cy.get(':nth-child(4) > .bloko-input-text').type('-')
      cy.get('.account-login-actions > .bloko-button').click()

      cy.get('.verification-header')
    })
    it('Позитивный кейс: верный номер', function() {
      cy.get(':nth-child(4) > .bloko-input-text').type('-')
      cy.get('.account-login-actions > .bloko-button').click()

      cy.get('.verification-header')
    })
    it('Негативный кейс: невалидный логин', function() {
      cy.get(':nth-child(4) > .bloko-input-text').type('yuqwriufneh')
      cy.get('.account-login-actions > .bloko-button').click()

      cy.get('.bloko-form-error')
    })
    it('Негативный кейс: вход c неверной почтой/паролем', function() {
      cy.get('.account-login-actions > .bloko-link').click()
      cy.get(':nth-child(7) > .bloko-input-text-wrapper > .bloko-input-text').type('qwerty@mail.ru')
      cy.get(':nth-child(8) > .bloko-input-text-wrapper > .bloko-input-text').type('12345678')
      cy.get('.account-login-actions > .bloko-button').click()

      cy.get('.bloko-form-error')
    })
    it('Негативный кейс: вход c неверным номером/паролем', function() {
      cy.get('.account-login-actions > .bloko-link').click()
      cy.get(':nth-child(7) > .bloko-input-text-wrapper > .bloko-input-text').type('89305307766')
      cy.get(':nth-child(8) > .bloko-input-text-wrapper > .bloko-input-text').type('12345678')
      cy.get('.account-login-actions > .bloko-button').click()
      
      cy.get('.bloko-form-error')
    })
})