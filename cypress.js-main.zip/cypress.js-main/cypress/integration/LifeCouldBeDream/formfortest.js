describe('form', function() {
    it('enter', function() {
        cy.visit('https://voronezh.hh.ru/account/login');
    })
})